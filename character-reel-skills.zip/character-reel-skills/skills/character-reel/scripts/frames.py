"""Index a short clip's presentation timestamps and extract selected decoded frames."""
import argparse
import csv
import json
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageOps


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=["overview", "detail"])
    p.add_argument("video", type=Path)
    p.add_argument("out", type=Path)
    p.add_argument("--first", type=int)
    p.add_argument("--last", type=int)
    a = p.parse_args()
    video = str(a.video.resolve())
    raw = subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "V:0",
                                   "-show_entries", "frame=best_effort_timestamp_time",
                                   "-of", "json", video])
    frames = json.loads(raw).get("frames", [])
    if not frames or any(f.get("best_effort_timestamp_time") in (None, "N/A") for f in frames):
        p.error("Readable video frames with presentation timestamps are required.")
    ts = [float(f["best_effort_timestamp_time"]) for f in frames]
    seconds = [t - ts[0] for t in ts]
    last = len(ts) - 1
    if a.mode == "detail":
        if a.first is None or a.last is None or not 0 <= a.first <= a.last <= last:
            p.error(f"Supply an inclusive --first/--last range from 0 to {last}.")
        selected = list(range(a.first, a.last + 1))
        select = f"between(n,{a.first},{a.last})"
    else:
        if a.first is not None or a.last is not None:
            p.error("Frame ranges apply to detail mode.")
        selected = sorted({round(i * last / 23) for i in range(24)})
        select = "+".join(f"eq(n,{i})" for i in selected)
    if a.out.exists():
        p.error("Choose a fresh output directory.")
    a.out.mkdir(parents=True)
    subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-i", video, "-map", "0:V:0",
                    "-vf", f"select='{select}'", "-fps_mode", "passthrough", "-start_number", "0",
                    str(a.out / "pick-%08d.png")], check=True)
    picks = sorted(a.out.glob("pick-*.png"))
    if len(picks) != len(selected):
        raise SystemExit("Frame count differs from index. Discard this run and check the clip.")
    names = {}
    for i, path in zip(selected, picks):
        names[i] = f"frame-{i:06d}.png"
        path.rename(a.out / names[i])
    with (a.out / "index.csv").open("w", newline="", encoding="utf-8") as out:
        writer = csv.writer(out)
        writer.writerow(["frame", "time_from_start_s", "source_pts_s", "exported_image"])
        writer.writerows((i, f"{seconds[i]:.6f}", f"{t:.6f}", names.get(i, ""))
                         for i, t in enumerate(ts))
    for start in range(0, len(selected), 24):
        page = selected[start:start + 24]
        cols = min(4, len(page))
        sheet = Image.new("RGB", (cols * 200, ((len(page) + cols - 1) // cols) * 196), "#222222")
        draw = ImageDraw.Draw(sheet)
        for pos, i in enumerate(page):
            x, y = (pos % cols) * 200, (pos // cols) * 196
            with Image.open(a.out / names[i]) as im:
                thumb = ImageOps.contain(im, (196, 171))
                sheet.paste(thumb, (x + (200 - thumb.width) // 2, y))
            draw.text((x + 4, y + 174), f"#{i}   {seconds[i]:.3f}s", fill="white")
        sheet.save(a.out / f"sheet-{start // 24 + 1:03d}.jpg", quality=88)
    print(f"{len(ts)} frames indexed, {len(selected)} exported to {a.out}")


if __name__ == "__main__":
    main()
