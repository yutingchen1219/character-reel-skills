"""Build a side-by-side JPEG, source on the left and character on the right."""
import argparse
from pathlib import Path
from PIL import Image, ImageOps


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("source", type=Path)
    p.add_argument("character", type=Path)
    p.add_argument("output", type=Path)
    args = p.parse_args()
    thumbs = []
    for path in (args.source, args.character):
        with Image.open(path) as im:
            thumbs.append(ImageOps.contain(ImageOps.exif_transpose(im).convert("RGB"), (512, 640)))
    width = max(im.width for im in thumbs)
    height = max(im.height for im in thumbs)
    canvas = Image.new("RGB", (2 * width + 4, height), "#222222")
    for i, im in enumerate(thumbs):
        canvas.paste(im, (i * (width + 4) + (width - im.width) // 2, (height - im.height) // 2))
    with args.output.open("xb") as dest:
        canvas.save(dest, "JPEG", quality=90)


if __name__ == "__main__":
    main()
